# FRONTEND DESIGN CASE STUDY REPORT
## "Beyond the Code" — Personal Portfolio Website

**Student Name:** Priya Darshini  
**Degree Program:** Integrated M.Tech in Computer Science and Engineering  
**Institution:** VIT Vellore (Vellore Institute of Technology)  
**Academic Course:** Frontend Design Case Study Project  
**Date:** October 2026  

---

### 1. Portfolio Name and Design Concept

- **Portfolio Name:** Beyond the Code
- **Tagline:** *"A little creativity. A lot of curiosity. Endless possibilities."*
- **Design Concept & Philosophy:**  
  The portfolio is crafted around a **Modern Editorial Aesthetic** featuring a signature **Lavender & Cream color system**. Rather than adopting standard dark-mode code dashboards or cliché template layouts, "Beyond the Code" reflects a blend of technical computer science rigor and editorial visual elegance. Generous whitespace, asymmetric card placement, refined typography, responsive project galleries, and purposeful micro-interactions communicate curiosity, developer professionalism, and creative problem-solving.

---

### 2. Website Creation Platform & Development Environment

- **Development Platform:** Custom Hand-Coded Web Application (Vanilla HTML/CSS/JS).
- **IDE / Editor:** Visual Studio Code (VS Code).
- **Tooling:** Browser Developer Tools (Chrome DevTools / Firefox Developer Edition) for responsive viewport testing and accessibility auditing.
- **Hosting Environment:** Static Web Hosting via **GitHub Pages**.

---

### 3. Technology Stack & External Dependencies

| Layer | Technologies & Dependencies | Purpose |
| :--- | :--- | :--- |
| **Markup & Semantics** | Semantic HTML5 | Structured, accessible page hierarchy (`<header>`, `<nav>`, `<main>`, `<section>`, `<article>`, `<footer>`). |
| **Styling Architecture** | CSS3 (Flexbox, CSS Grid, `:root` Variables) | Custom layout grids, responsive media queries, editorial typography scales, status badges, and CSS accordion transitions. |
| **Interactivity** | Vanilla JavaScript (ES6+) | Mobile navigation drawer, active section highlighting, `IntersectionObserver` scroll reveals, expandable project detail accordions, client-side regex validation. |
| **Typography** | Google Fonts (`Playfair Display`, `Inter`) | `Playfair Display` for expressive serif section headings; `Inter` for clean body UI readability. |
| **Iconography** | Lucide Icons (via CDN) | Lightweight, vector SVG icons (`<i data-lucide="...">`) for UI clarity. |
| **Deployment** | GitHub Pages | Static website publishing. |

---

### 4. Template & Customization Documentation (Before & After Evidence Guide)

#### Template Disclosure Notice:
> **Original Development Status:** This portfolio was **built from scratch (custom development)** specifically for this case study project. **No third-party website template or pre-built Bootstrap/HTML starter theme was downloaded or modified.**

#### Screenshot Evidence Guide for Report Submission:

| Stage | Description of Evidence | Screenshot Capture Instructions for Student |
| :--- | :--- | :--- |
| **Before (Initial Concept & Wireframe)** | Wireframe design draft / HTML skeletal markup before CSS styling was applied. | Open `index.html` with stylesheet link temporarily commented out, or capture wireframe sketches/Figma layout drafts. |
| **After (Final Custom Implementation)** | Polished editorial UI with custom Lavender & Cream palette, fonts, 6-project expandable card grid and four certificate PDF links, and responsive layouts. | Capture full-page desktop screenshot (1440px) and mobile screenshot (375px) using Chrome DevTools screenshot tool. |

---

### 5. Customizations & Implemented Features

1. **Editorial Lavender & Cream Palette:** Custom CSS color variables (`:root`) enabling single-point customization.
2. **Hero Intro Card Component:** Glassmorphism overlay card featuring profile photograph, badges, and smooth scroll buttons.
3. **6-Project Expandable Gallery:** Responsive project showcase containing:
   - *Civic Connect* (Web Development / Civic Tech)
   - *Sign Language Detector* (Machine Learning / Computer Vision)
   - **BrainBuddy* (Completed Software Project)
   - *AI-Based Crop Yield Prediction System* (Completed Microproject)
   - *StockGuard* (Business Tech / Inventory Management Concept)
   - *Patent Novelty Checker* (AI-Assisted Research / Intellectual Property Concept)
4. **Expandable Detail Accordions:** Interactive "View Details" buttons with smooth CSS accordion expansion.
5. **Clear Project Status Badges:** Visual badges distinguishing Completed Projects, Academic Coursework, Concepts, and Editable placeholders.
6. **Responsive Grid & Flex Layouts:** 3-column desktop to 1-column mobile adaptive project grid.
7. **Interactive Skill Pills:** Icon-assisted skill cards grouped into Programming, Frontend, Database, Tools, and Areas of Interest.
8. **Timeline Education Display:** Vertical connected timeline displaying Integrated M.Tech CSE at VIT Vellore and previous schooling.
9. **Certificate Card State:** Modular certificate cards supporting verification links and upcoming state notices.
10. **Client-Side Form Validation:** JavaScript input validation with regex error checking and success banner alerts.

---

### 6. Design Inspiration

- **Wall of Portfolios & Editorial Web Design:** Inspired by contemporary editorial typography layouts on platforms such as [Wall of Portfolios](https://www.wallofportfolios.in/).
- **Framer Portfolio Architecture:** Clean spacing, large serif typography headlines, and micro-interactions observed in top-tier creative developer portfolios.

---

### 7. Color, Typography, and Layout Rationale

- **Color Palette Rationale:**
  - `Background (#FAF7F2)`: Warm cream reduces eye fatigue compared to harsh `#FFFFFF` and provides a tactile, paper-like editorial feel.
  - `Primary Purple (#5B3A82)`: Represents intellect, creativity, and academic depth while maintaining high contrast.
  - `Lavender Accent (#C8B6E2)`: Soft pastel lavender brings visual warmth and draws attention to interactive badges and focus states.
  - `Dark Text (#29252E)`: Charcoal text ensures contrast compliance (WCAG AAA) without stark black harshness.
- **Typography Rationale:**
  - `Playfair Display` (Serif): Adds character, human warmth, and elegance to section titles and headlines.
  - `Inter` (Sans-Serif): Highly legible geometric sans-serif optimized for screen rendering across mobile and desktop.
- **Layout Rationale:**
  - Asymmetric editorial balance in Hero and About sections to create visual rhythm.
  - 3-column responsive grid for 6 project cards with uniform aspect ratio vector graphics.

---

### 8. References Used

1. **MDN Web Docs:** HTML5 Semantic Elements & CSS Grid Layout Guides ([https://developer.mozilla.org/](https://developer.mozilla.org/))
2. **Google Fonts Directory:** Font pairing specs for Playfair Display & Inter ([https://fonts.google.com/](https://fonts.google.com/))
3. **Lucide Icons Documentation:** SVG Icon Integration Guides ([https://lucide.dev/](https://lucide.dev/))
4. **GitHub Pages Documentation:** Static Site Deployment Instructions ([https://pages.github.com/](https://pages.github.com/))
5. **Wall of Portfolios Inspiration:** Editorial layout and portfolio design trends ([https://www.wallofportfolios.in/](https://www.wallofportfolios.in/))

---

### 9. AI Tools, Prompts, and Pair Programming Documentation

- **AI Assistant Used:** Google Antigravity Agentic Coding Assistant.
- **Role of AI:** Acted as an expert frontend developer, UI/UX designer, and pair programming assistant to structure code, enforce WCAG accessibility, implement responsive breakpoints, write vanilla JS logic, and formulate documentation.
- **Key Prompt Summary:**
  > *"Develop and update personal portfolio website 'Beyond the Code' for Priya Darshini, CS student at VIT Vellore. Showcase all 6 projects with expandable details, status badges, lavender/cream editorial styling, vanilla HTML/CSS/JS, full responsiveness, and completed project/certificate details."*

---

### 10. Live Portfolio URL

- **Deployment Platform:** GitHub Pages
- **Live URL:** To be added after GitHub Pages deployment.
- **Repository URL:** To be added after creating the GitHub repository.

---
